<?php
/*
 * Plugin Name: medisom extra
 * Version: 1.0.0
 * Description: brug naar eigen ontwikkeling
 * Author: Bernhard Kau
 * Author URI: http://edisom.nle
 * Plugin URI: 
 * Text Domain: medisom
 * Domain Path: /languages
 * License: GPLv3
 * License URI: http://www.gnu.org/licenses/gpl-3.0
*/
function sys( ) {
	$post_data = get_post(null, ARRAY_A);
	$slug = $post_data['post_name'];
	include  'C:\xampp\htdocs\medisom.nl\wp-content\plugins\medisom-extra\sm\wp_'.$slug.'.php';	
}
add_shortcode( 'sys', 'sys' );
?>